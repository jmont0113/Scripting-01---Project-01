Player Movement Controls - 

W Key - Pushes the player forward
S Key - Pushes the player backwards
D Key - Turns the player right
A Key - Turns the player left
Escape Key - Exit program application 
